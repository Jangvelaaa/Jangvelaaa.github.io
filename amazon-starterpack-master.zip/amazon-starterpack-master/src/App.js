import "./App.css";

function App() {
  return (
    <div className="App">
      <span>Subscribe Zainkeepscode</span>
    </div>
  );
}

export default App;
